"""
Vector store wrapper around ChromaDB.

Chroma stores each chunk's vector (from embeddings.py) alongside its
original text and metadata (filename, page number). Later, given a new
vector (from a user's question), it can instantly find the chunks whose
vectors are closest -- this is the "search by meaning" step.
"""

import chromadb

from .chunker import Chunk
from .embeddings import EmbeddingProvider


class VectorStore:
    def __init__(self, embedder: EmbeddingProvider, persist_dir: str, collection_name: str = "knowledge_base"):
        self.embedder = embedder
        self.client = chromadb.PersistentClient(path=persist_dir)
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},  # cosine similarity = standard for semantic search
        )

    def add_chunks(self, chunks: list[Chunk]) -> None:
        if not chunks:
            return

        vectors = self.embedder.embed([c.text for c in chunks])

        self.collection.upsert(
            ids=[c.id for c in chunks],
            embeddings=vectors,
            documents=[c.text for c in chunks],
            metadatas=[
                {"source_filename": c.source_filename, "page_number": c.page_number}
                for c in chunks
            ],
        )

    def query(self, question: str, top_k: int = 5) -> list[dict]:
        """
        Returns the top_k most similar chunks to the question, each with:
        - text
        - source_filename, page_number (for citation)
        - similarity (0-1, higher = more relevant)
        """
        query_vector = self.embedder.embed([question])[0]

        results = self.collection.query(
            query_embeddings=[query_vector],
            n_results=top_k,
        )

        matches = []
        for i in range(len(results["ids"][0])):
            distance = results["distances"][0][i]
            similarity = 1 - distance  # cosine distance -> similarity
            matches.append(
                {
                    "text": results["documents"][0][i],
                    "source_filename": results["metadatas"][0][i]["source_filename"],
                    "page_number": results["metadatas"][0][i]["page_number"],
                    "similarity": similarity,
                }
            )
        return matches

    def count(self) -> int:
        return self.collection.count()

    def list_sources(self) -> list[dict]:
        """
        Returns each distinct source document currently in the store,
        with how many chunks it contributed. Used by the /documents
        endpoint so the frontend can show what's actually loaded.
        """
        if self.collection.count() == 0:
            return []

        all_records = self.collection.get(include=["metadatas"])
        counts: dict[str, int] = {}
        for meta in all_records["metadatas"]:
            filename = meta["source_filename"]
            counts[filename] = counts.get(filename, 0) + 1

        return [{"filename": name, "chunks": n} for name, n in sorted(counts.items())]
