"""
Wraps our RAG retrieval (embeddings + vector store + line-highlighting)
as a single callable TOOL the orchestrator's LLM can choose to invoke --
exactly like send_email or create_ticket. This is what lets one assistant
decide, per message, whether it needs to look something up in the
documents at all.
"""

from backend.rag.highlight import find_relevant_lines

RELEVANCE_THRESHOLD = 0.3


def make_search_tool(store, embedder):
    """
    Factory function: bakes the vector store and embedder into a plain
    function with the signature/docstring the LLM needs to see, without
    the LLM ever needing to know these dependencies exist.
    """

    def search_knowledge_base(query: str) -> str:
        """Searches the company's internal documents for information relevant to a query.

        Use this whenever the user asks something that might be answered by
        the uploaded documents -- facts about people, projects, policies, or
        any specific content that could live in the knowledge base. Do not
        rely on your own general knowledge for such questions.

        Args:
            query: A focused search query describing what information is needed.
        """
        matches = store.query(query, top_k=3)
        relevant = [m for m in matches if m["similarity"] >= RELEVANCE_THRESHOLD]

        print(f'\n  [ACTION] Searching knowledge base for: "{query}"')

        if not relevant:
            print("    -> No sufficiently relevant information found.\n")
            return (
                "No relevant information was found in the knowledge base for this query. "
                "Tell the user you couldn't find this in the documents -- do not guess."
            )

        context_blocks = []
        for m in relevant[:2]:
            lines = find_relevant_lines(query, m["text"], embedder, top_n=2)
            print(f"    -> Found in {m['source_filename']}, page {m['page_number']}:")
            for line in lines:
                print(f'       "{line}"')
            context_blocks.append(
                f"[Source: {m['source_filename']}, page {m['page_number']}]\n{m['text']}"
            )
        print()

        return "\n\n".join(context_blocks)

    return search_knowledge_base
